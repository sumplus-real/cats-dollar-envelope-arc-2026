CATS Portable Recovery Kit

Start an independent HTTP server from this directory, then open /web/recovery.html. Wallet extensions may not work on file://. No CDN, app API, operator process or private key is included. RPC access and an EIP-1193 wallet are required.

Before signing, verify chain 5042, deployment bytecode hash, fixed owner and root on the live chain. Close the root, release Offered funds, withdraw free balances. Accepted fees cannot be reclaimed by the owner. Payees may independently call claim(grantId) on the verified contract even after expiry; rejection leaves their credit intact.

Review the current exit Gas envelope. Gas limits govern this app, not every wallet transaction. Unknown retains reserves and must be checked by hash/nonce; never blindly resend. The downloaded code validates the live ledger, not a saved screenshot. An edited digest is not a trust anchor: obtain the package hash from a trusted copy.

This package may be a LOCAL fixture. Its deployment.json explicitly says so. Local evidence is never Arc mainnet evidence.
